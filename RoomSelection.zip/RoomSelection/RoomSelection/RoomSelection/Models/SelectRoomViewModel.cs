﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace RoomSelection.Models
{
    public class SelectRoomViewModel
    {
        public string[] Rooms { get; set; }

        [Display(Name = "Räume:")]
        [Required(ErrorMessage = "Wähle einen Raum aus!")]
        public string? SelectedRoom { get; set; }
    }
}
public record Room(string Name);