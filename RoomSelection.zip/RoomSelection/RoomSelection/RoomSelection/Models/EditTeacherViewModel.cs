﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace RoomSelection.Models
{
    public class EditTeacherViewModel
    {

        public int NewId { get; set; }

        [Display(Name = "Kürzel:")]
        public string? NewKuerzel { get; set; }

        [Display(Name = "Titel:")]
        public string? NewTitle { get; set; }

        [Display(Name = "Vorname:")]
        public string? NewFirstname { get; set; }

        [Display(Name = "Nachname:")]
        public string? NewLastname { get; set; }

        [Display(Name = "Foto auswählen:")]
        public IFormFile? Foto { get; set; }

        [Display(Name = "Räume:")]
        public string? NewRoom { get; set; }
    }
}
