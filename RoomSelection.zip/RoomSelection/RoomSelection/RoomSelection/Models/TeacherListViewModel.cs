﻿using RoomSelection.Controllers;

namespace RoomSelection.Models
{
    public class TeacherListViewModel
    {
        public int Id { get; set; }
        public string? Foto { get; set; }
        public string? Vorname { get; set; }
        public string? Nachname { get; set; }
        public string? Kuerzel { get; set; }
        public string? Titel { get; set; }
        public string? Room { get; set; }
    }
}
