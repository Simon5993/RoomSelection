﻿using Microsoft.AspNetCore.Mvc;
using RoomSelection.Models;

namespace RoomSelection.Controllers
{
    public class SelectRoomController : Controller
    {
        public IActionResult SelectRoom()
        {
            return View(LoadModel());
        }

        public IActionResult Save(TeacherListViewModel model, SelectRoomViewModel model2)
        {
                      
            return RedirectToAction(nameof(TeacherListController.TeacherList), "TeacherList");
        }

        private static SelectRoomViewModel LoadModel()
        {
            string[] rooms = ImportCSV("rooms.csv");

            return new()
            {

                Rooms = rooms
                    
            };
                           
        }

        // Die CSV-Datei muss in UTF-8 codiert sein!
        public static string[] ImportCSV(string path)
        {
            var rooms = System.IO.File.ReadAllLines(path);

            for(int i = 0; i < rooms.Length; i++)
            {
                rooms[i] = rooms[i].Replace(";", " | ");
            }
            return rooms;
        }
    }
}