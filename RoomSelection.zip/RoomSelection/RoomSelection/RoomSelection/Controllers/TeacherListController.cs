﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.FlowAnalysis.DataFlow;
using RoomSelection.Models;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Text;


namespace RoomSelection.Controllers
{
    public class TeacherListController : Controller
    {


        string? filePath;
        List<TeacherListViewModel>? teacherList;

        [HttpPost]
        public IActionResult Update(EditTeacherViewModel updatedTeacher)
        {
            if (ModelState.IsValid)
            {
                teacherList = GetTeacherFromCSV("teacher.csv");

                TeacherListViewModel teacherToUpdate = teacherList.FirstOrDefault(t => t.Id == updatedTeacher.NewId);

                if (teacherToUpdate != null)
                {
                    teacherToUpdate.Kuerzel = updatedTeacher.NewKuerzel;
                    teacherToUpdate.Vorname = updatedTeacher.NewFirstname;
                    teacherToUpdate.Nachname = updatedTeacher.NewLastname;
                    teacherToUpdate.Titel = updatedTeacher.NewTitle;
                    teacherToUpdate.Room = updatedTeacher.NewRoom;

                    SaveTeacherToCSV(teacherList);

                    return RedirectToAction("TeacherList");
                }
            }

            return View("Edit", updatedTeacher);
        }

        private void SaveTeacherToCSV(List<TeacherListViewModel> teacherList)
        {
            string filePath = "teacher.csv";

            using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.UTF8))
            {
                foreach (var teacher in teacherList)
                {
                    // Schreibe die aktualisierten Daten jedes Lehrers in die CSV-Datei
                    writer.WriteLine($"{teacher.Kuerzel};{teacher.Vorname};{teacher.Nachname};{teacher.Titel};{teacher.Room}");
                }
            }
        }

        private TeacherListViewModel GetTeacherById(int id)
        {
            filePath = "teacher.csv";
            teacherList = GetTeacherFromCSV(filePath);

            // Annahme: Suche nach dem Lehrer anhand der ID in der Datenquelle
            return teacherList.Find(teacher => teacher.Id == id);
        }

        public IActionResult EditTeacher(int id)
        {
            TeacherListViewModel teacher = GetTeacherById(id);
            EditTeacherViewModel editTeacher = new EditTeacherViewModel
            {
                NewId = teacher.Id,
                NewKuerzel = teacher.Kuerzel,
                NewTitle = teacher.Titel,
                NewFirstname = teacher.Vorname,
                NewLastname = teacher.Nachname,
                NewRoom = teacher.Room,
            };
            return View(editTeacher);
        }

        public IActionResult RoomSelection(int id, SelectRoomViewModel model, TeacherListViewModel model2)
        {
            return RedirectToAction(nameof(SelectRoomController.SelectRoom), "SelectRoom");
        }

        public IActionResult TeacherList()
        {
            string filePath = "teacher.csv";

            List<TeacherListViewModel> teacherList = GetTeacherFromCSV(filePath);
            return View(teacherList);
        }

        public List<TeacherListViewModel> GetTeacherFromCSV(string filePath)
        {
            List<TeacherListViewModel> teacherList = new List<TeacherListViewModel>();

            using (var reader = new StreamReader(filePath))
            {
                int i = 0;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');


                    if (values.Length >= 2)
                    {
                        var teacher = new TeacherListViewModel
                        {
                            Kuerzel = values[0],
                            Vorname = values[1],
                            Nachname = values[2],
                            Titel = values[3],
                            Foto = "http://sis/images/lehrerfotos/" + values[0] + ".jpg",
                            Id = i,
                           Room = values[4],
                        };
                        teacherList.Add(teacher);
                    }
                    i++;
                }

            }
            return teacherList;
        }
    }
}