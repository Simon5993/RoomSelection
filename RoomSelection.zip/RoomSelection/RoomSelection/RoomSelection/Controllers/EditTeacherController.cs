﻿using Microsoft.AspNetCore.Mvc;

namespace RoomSelection.Controllers
{
    public class EditteacherController : Controller
    {
        public IActionResult EditTeacher()
        {
            return View();
        }

        public IActionResult TeacherList()
        {
            return View();
        }
    }
}
